# serverless-demo-api
API project used as a demo in the serverless lunch and learn at KIS
